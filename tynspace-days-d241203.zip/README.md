

чего бугузить

![ship_a](./resources/spaceships/ship_A.png)

![ship_b](./resources/spaceships/ship_B.png)

![ship_c](./resources/spaceships/ship_C.png)

![ship_d](./resources/spaceships/ship_D.png)

![ship_e](./resources/spaceships/ship_E.png)

![background-inf](./in/f/Back-1b.png)

<a href="https://github.com/tynrare/spacedays/blob/main/in/nebulas">
<img src="https://github.com/tynrare/spacedays/blob/main/in/nebulas/nebula01_512.png">
</a>
